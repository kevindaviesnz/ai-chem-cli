import os
from litellm import completion

def predict_reaction(reactants: list, model: str) -> str:
    """Predicts reaction outcomes using the specified AI model."""
    prompt = (
        f"Act as an expert computational chemist. Predict the major products of the reaction "
        f"between the following reactants: {', '.join(reactants)}. "
        f"Provide the predicted product SMILES and a brief mechanistic explanation."
    )
    return _call_llm(prompt, model)

def propose_pathway(target: str, model: str) -> str:
    """Proposes a synthesis pathway using the specified AI model."""
    prompt = (
        f"Act as an expert computational chemist. Propose a high-yield retrosynthetic "
        f"pathway for the target molecule: {target}. "
        f"Include reagents, reaction conditions, and intermediate chemical names or SMILES."
    )
    return _call_llm(prompt, model)

def _call_llm(prompt: str, model: str) -> str:
    """Handles the LiteLLM routing and basic error handling."""
    try:
        response = completion(
            model=model,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.choices[0].message.content
    except Exception as e:
        return (
            f"\n[!] AI Request Failed: {str(e)}\n"
            f"Ensure you have set the appropriate environment variable for the model "
            f"(e.g., OPENAI_API_KEY, GEMINI_API_KEY, ANTHROPIC_API_KEY)."
        )
