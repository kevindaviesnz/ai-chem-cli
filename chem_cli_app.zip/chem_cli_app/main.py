import click
import sys
from chem_utils import validate_smiles, get_molar_mass
from ai_router import predict_reaction, propose_pathway

@click.command()
@click.option('-r', '--reactants', multiple=True, help="Reactants for the simulation (names or SMILES). Use multiple times for multiple reactants.")
@click.option('-s', '--simulate', is_flag=True, help="Simulate the reaction between provided reactants.")
@click.option('-p', '--pathway', help="Target molecule to propose a synthesis pathway for.")
@click.option('-m', '--model', default="gpt-4o", help="Specify the AI model to handle generative tasks (default: gpt-4o).")
def cli(reactants, simulate, pathway, model):
    """Chem CLI: Chemical calculations, simulation, and synthesis planning."""
    
    if not simulate and not pathway:
        click.echo("Error: Please provide an action. Use --help for options.")
        sys.exit(1)

    # Reaction Simulation Logic
    if simulate:
        if not reactants:
            click.echo("Error: --simulate requires at least one --reactants (-r).")
            sys.exit(1)
            
        click.echo(click.style("Validating inputs...", fg="blue"))
        for r in reactants:
            # Simple heuristic to guess if input is SMILES
            if any(c in r for c in ['=', '#', '(', ')']):
                try:
                    validate_smiles(r)
                    mass = get_molar_mass(r)
                    click.echo(f"  [✓] Valid SMILES detected: {r} (Mass: {mass:.2f} g/mol)")
                except ValueError:
                    click.echo(f"  [!] Warning: '{r}' does not appear to be a valid SMILES. Treating as a common name.")
            else:
                 click.echo(f"  [-] Treating '{r}' as a chemical name.")
                 
        click.echo(click.style(f"\nSimulating reaction using model: {model}...\n", fg="green", bold=True))
        result = predict_reaction(reactants, model=model)
        click.echo(result)

    # Synthesis Pathway Logic
    if pathway:
        click.echo(click.style(f"\nProposing synthesis pathway for '{pathway}' using model: {model}...\n", fg="green", bold=True))
        result = propose_pathway(pathway, model=model)
        click.echo(result)

if __name__ == '__main__':
    cli()
