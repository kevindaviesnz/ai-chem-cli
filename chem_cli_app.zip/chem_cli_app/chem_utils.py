from rdkit import Chem
from rdkit.Chem import Descriptors

def validate_smiles(smiles: str) -> bool:
    """Validates a SMILES string using RDKit."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Invalid SMILES string: {smiles}")
    return True

def get_molar_mass(smiles: str) -> float:
    """Calculates the exact molar mass of a molecule from its SMILES."""
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        return Descriptors.ExactMolWt(mol)
    return 0.0
